console.log(process.env);
const firebaseConfig = {
  apiKey: "AIzaSyC45prZWGaPFkNU7G6s7BOKyud3sxMNog8",
  authDomain: "medicare-hospitals-ltd.firebaseapp.com",
  projectId: "medicare-hospitals-ltd",
  storageBucket: "medicare-hospitals-ltd.appspot.com",
  messagingSenderId: "861039841854",
  appId: "1:861039841854:web:3fa82f0ce17306945d776f"
};

export default firebaseConfig;