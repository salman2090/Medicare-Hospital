<h1>Project Title: MediCare Hospital</h1>

<h3>Site Link: https://medicare-hospitals-ltd.web.app/ </h3>

<h3>About the project:</h3>

<p>This project is mainly an hospital management website where we can provide our client convenient service. Our client can choose their preffered specialists and desired branches by browsing this website to make his decision comfortably.</p>

<ul>
    <li>Our Hospital is providing a range of different services from surgery to transportation.</li>
    <li>You can checkout our specialists with their speciality and degrees.</li>
    <li>We possess a range of branches located in major cities and you can find the locations in Visit Us section.</li>
    <li>Our client has to connect with us by an authentication system to check our services for to maintain the safety rules.</li>
    <li>We have provided various online payment which you can find in our footer section.</li>
</ul>